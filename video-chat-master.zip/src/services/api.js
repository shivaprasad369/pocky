import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:9900/api',
});

// Add auth token to requests
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });

export default {
  // Auth
  register: (username, email, password) =>
    api.post('/auth/register', { username, email, password }),
  login: (email, password) =>
    api.post('/auth/login', { email, password }).then(res => res.data),
  getProfile: () => api.get('/auth/profile').then(res => res.data),
  // User
  getProfile: () => api.get('/users/me').then(res => res.data),
  getInterests: () => api.get('/api/interests').then(res => res.data),
  // Chat
//   findRandomMatch: () => api.post('/chat/find-random'),
  findRandomMatch: (socketId) => 
    api.post('/chat/find-random', null, {
      headers: {
        'X-Socket-ID': socketId
      }
    }),
  findMatch: (interests) =>
    api.post('/chat/find-match', { interests }).then(res => res.data.sessionId),
  getSession: (sessionId) =>
    api.get(`/chat/sessions/${sessionId}`).then(res => res.data),
  reportUser: (sessionId, reportedUserId, reason) =>
    api.post('/chat/report', { sessionId, reportedUserId, reason }),

  // Interests
  getInterests: () => api.get('/interests').then(res => res.data),
};