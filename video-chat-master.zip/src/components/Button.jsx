import React from 'react';

const Button = ({ children, onClick, className = '', disabled = false, variant = 'primary' }) => {
  const variants = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white',
    danger: 'bg-red-600 hover:bg-red-700 text-white',
    secondary: 'bg-gray-600 hover:bg-gray-700 text-white',
    outline: 'border border-gray-600 hover:bg-gray-100 text-gray-800'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`px-4 py-2 rounded-md transition ${variants[variant]} ${className}`}
    >
      {children}
    </button>
  );
};

export default Button;