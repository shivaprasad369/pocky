import { useEffect, useRef, useState } from 'react';
import Peer from 'peerjs';
import { useSocket } from '../contexts/SocketContext';
import { useUser } from '../contexts/UserContext';

const VideoChat = ({ sessionId, onDisconnect }) => {
  const [peer, setPeer] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const { socket } = useSocket();
  const { user } = useUser();

  useEffect(() => {
    const initializePeer = async () => {
      const newPeer = new Peer({
        host: import.meta.env.VITE_PEER_HOST || 'localhost',
        port: import.meta.env.VITE_PEER_PORT || 9000,
        path: '/peerjs',
        secure: import.meta.env.VITE_PEER_SECURE === 'true',
      });

      newPeer.on('open', (id) => {
        socket.emit('join-video-chat', { sessionId, peerId: id, userId: user?.id });
      });

      newPeer.on('call', (call) => {
        // In the getUserMedia calls, use these constraints:
navigator.mediaDevices.getUserMedia({
    video: {
      width: { ideal: 1280 },
      height: { ideal: 720 },
      frameRate: { ideal: 30, min: 20 },
      facingMode: 'user'
    },
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      channelCount: 2,
      sampleRate: 48000,
      sampleSize: 16,
      volume: 1.0
    }
  })
      });

      setPeer(newPeer);

      return () => {
        newPeer.destroy();
      };
    };

    initializePeer();

    socket.on('user-connected', (peerId) => {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then((stream) => {
          localVideoRef.current.srcObject = stream;
          const call = peer.call(peerId, stream);
          
          call.on('stream', (remoteStream) => {
            setRemoteStream(remoteStream);
            remoteVideoRef.current.srcObject = remoteStream;
            setIsConnected(true);
          });
        })
        .catch((err) => {
          console.error('Failed to get local stream', err);
        });
    });

    socket.on('user-disconnected', () => {
      setIsConnected(false);
      if (remoteVideoRef.current?.srcObject) {
        remoteVideoRef.current.srcObject.getTracks().forEach(track => track.stop());
        remoteVideoRef.current.srcObject = null;
      }
    });

    return () => {
      socket.off('user-connected');
      socket.off('user-disconnected');
    };
  }, [sessionId, socket, user]);

  const handleDisconnect = () => {
    if (localVideoRef.current?.srcObject) {
      localVideoRef.current.srcObject.getTracks().forEach(track => track.stop());
      localVideoRef.current.srcObject = null;
    }
    if (remoteVideoRef.current?.srcObject) {
      remoteVideoRef.current.srcObject.getTracks().forEach(track => track.stop());
      remoteVideoRef.current.srcObject = null;
    }
    socket.emit('leave-video-chat', { sessionId, userId: user?.id });
    onDisconnect();
  };

  return (
    <div className="flex flex-col items-center justify-center h-full bg-gray-900 p-4">
      <div className="relative w-full max-w-4xl h-96 mb-4 rounded-lg overflow-hidden">
        {remoteStream ? (
          <video
            ref={remoteVideoRef}
            className="w-full h-full object-cover"
            autoPlay
            playsInline
          />
        ) : (
          <div className="w-full h-full bg-gray-800 flex items-center justify-center">
            <p className="text-white">Waiting for connection...</p>
          </div>
        )}
        <div className="absolute bottom-4 left-4 w-32 h-32 rounded-lg overflow-hidden border-2 border-white">
          <video
            ref={localVideoRef}
            className="w-full h-full object-cover"
            autoPlay
            playsInline
            muted
          />
        </div>
      </div>
      
      <div className="flex gap-4">
        <button
          onClick={handleDisconnect}
          className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
        >
          Disconnect
        </button>
      </div>
    </div>
  );
};

export default VideoChat;