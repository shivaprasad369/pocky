import { useState, useEffect, useCallback } from 'react';
import Peer from 'peerjs';

const usePeer = () => {
  const [peer, setPeer] = useState(null);
  const [peerId, setPeerId] = useState('');
  const [error, setError] = useState(null);

  const createPeer = useCallback(() => {
    const newPeer = new Peer({
      host: import.meta.env.VITE_PEER_HOST || 'localhost',
      port: import.meta.env.VITE_PEER_PORT || 9000,
      path: '/peerjs',
      secure: import.meta.env.VITE_PEER_SECURE === 'true',
    });

    newPeer.on('open', (id) => {
      setPeerId(id);
    });

    newPeer.on('error', (err) => {
      console.error('Peer error:', err);
      setError(err);
    });

    setPeer(newPeer);

    return () => {
      newPeer.destroy();
    };
  }, []);

  useEffect(() => {
    return createPeer();
  }, [createPeer]);

  return { peer, peerId, error };
};

export default usePeer;