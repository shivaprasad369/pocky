import { useState, useEffect } from 'react';

const useMediaStream = (constraints = { video: true, audio: true }) => {
  const [stream, setStream] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mediaStream = null;

    const getStream = async () => {
      try {
        mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
        setStream(mediaStream);
      } catch (err) {
        console.error('Failed to get media stream', err);
        setError(err);
      }
    };

    getStream();

    return () => {
      if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [constraints]);

  return { stream, error };
};

export default useMediaStream;