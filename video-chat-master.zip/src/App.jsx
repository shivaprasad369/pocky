import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { SocketProvider } from './contexts/SocketContext.jsx';

import socket from './utils/socket';
import HomePage from './pages/HomePage';
import ChatPage from './pages/ChatPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import { UserProvider } from './contexts/UserContext.jsx';

function App() {
  return (
    <BrowserRouter>
      <UserProvider>
        <SocketProvider socket={socket}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/chat/:sessionId" element={<ChatPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </SocketProvider>
      </UserProvider>
    </BrowserRouter>
  );
}

export default App;