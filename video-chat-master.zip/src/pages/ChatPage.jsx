import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSocket } from '../contexts/SocketContext';
import { useUser } from '../contexts/UserContext';
import usePeer from '../hooks/usePeer';
import useMediaStream from '../hooks/useMediaStream';
import VideoPlayer from '../components/VideoPlayer';
import Button from '../components/Button';
import api from '../services/api';

const ChatPage = () => {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const socket = useSocket();
  const { user } = useUser();
  const { peer, peerId } = usePeer();
  const { stream: localStream } = useMediaStream();
  const [remoteStream, setRemoteStream] = useState(null);
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState('');
  const [partner, setPartner] = useState(null);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!socket || !peer || !peerId || !localStream) return;

    const handleMatchFound = ({ peerId: partnerPeerId, isInitiator }) => {
      setPartner({ peerId: partnerPeerId });

      if (isInitiator) {
        const call = peer.call(partnerPeerId, localStream);
        call.on('stream', (remoteStream) => {
          setRemoteStream(remoteStream);
        });
      }

      peer.on('call', (call) => {
        call.answer(localStream);
        call.on('stream', (remoteStream) => {
          setRemoteStream(remoteStream);
        });
      });
    };

    const handleMessage = (message) => {
      setMessages(prev => [...prev, { text: message, isMe: false }]);
    };

    const handleDisconnect = () => {
      setRemoteStream(null);
      setPartner(null);
      navigate('/', { state: { message: 'Partner disconnected' } });
    };

    socket.emit('join-chat', { sessionId, peerId, userId: user?.id });
    socket.on('match-found', handleMatchFound);
    socket.on('message', handleMessage);
    socket.on('partner-disconnected', handleDisconnect);

    return () => {
      socket.off('match-found', handleMatchFound);
      socket.off('message', handleMessage);
      socket.off('partner-disconnected', handleDisconnect);
      socket.emit('leave-chat', { sessionId, userId: user?.id });
    };
  }, [socket, peer, peerId, localStream, sessionId, user, navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = () => {
    if (!message.trim()) return;
    
    socket.emit('send-message', { sessionId, message });
    setMessages(prev => [...prev, { text: message, isMe: true }]);
    setMessage('');
  };

  const handleDisconnect = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    if (remoteStream) {
      remoteStream.getTracks().forEach(track => track.stop());
    }
    navigate('/');
  };

  const reportUser = () => {
    if (!partner) return;
    api.reportUser(sessionId, partner.id, 'Inappropriate behavior');
    alert('User reported successfully');
    handleDisconnect();
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900">
      <div className="flex-1 flex flex-col md:flex-row">
        <div className="flex-1 p-4">
          <div className="relative h-full rounded-lg overflow-hidden bg-gray-800">
            {remoteStream ? (
              <VideoPlayer stream={remoteStream} className="h-full" />
            ) : (
              <div className="flex items-center justify-center h-full">
                <p className="text-white">Waiting for partner to connect...</p>
              </div>
            )}
            {localStream && (
              <div className="absolute bottom-4 right-4 w-32 h-32 rounded-lg overflow-hidden border-2 border-white">
                <VideoPlayer stream={localStream} isLocal className="h-full" />
              </div>
            )}
          </div>
        </div>

        <div className="w-full md:w-80 bg-gray-800 flex flex-col">
          <div className="p-4 border-b border-gray-700">
            <h3 className="text-white font-semibold">
              {partner ? `Chatting with ${partner.username}` : 'Waiting for partner...'}
            </h3>
          </div>

          <div className="flex-1 p-4 overflow-y-auto">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`mb-3 ${msg.isMe ? 'text-right' : 'text-left'}`}
              >
                <div
                  className={`inline-block px-3 py-2 rounded-lg ${msg.isMe ? 'bg-blue-600 text-white' : 'bg-gray-700 text-white'}`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t border-gray-700">
            <div className="flex gap-2 mb-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Type a message..."
                className="flex-1 px-3 py-2 rounded bg-gray-700 text-white focus:outline-none"
              />
              <Button onClick={sendMessage} className="px-4">
                Send
              </Button>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleDisconnect}
                variant="danger"
                className="flex-1"
              >
                Disconnect
              </Button>
              <Button
                onClick={reportUser}
                variant="secondary"
                className="flex-1"
              >
                Report
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;