import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import Button from '../components/Button';
import api from '../services/api';
import { useSocket } from '../contexts/SocketContext';


const HomePage = () => {
  const [interests, setInterests] = useState([]);
  const [selectedInterests, setSelectedInterests] = useState([]);
  const [loading, setLoading] = useState(false);
  const { user, loading: userLoading } = useUser();
  const navigate = useNavigate();
  const socket = useSocket();
  useEffect(() => {
    if (!loading && !user) {
      navigate('/login');
    }
  }, [user, loading, navigate]);

  if (loading) {
    return <div>Loading...</div>;
  }
  // Fetch interests when component mounts
  useEffect(() => {
    if (socket) {
      socket.on('connect', () => {
        setSocketStatus('connected');
      });
      
      socket.on('disconnect', () => {
        setSocketStatus('disconnected');
      });
    }
  }, [socket]);

  const handleRandomMatch = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!socket?.id) {
      console.error('Socket not connected');
      return;
    }

    setLoading(true);
    try {
      const response = await api.findRandomMatch(socket.id);
      
      if (response.status === 'matched') {
        navigate(`/chat/${response.sessionId}`);
      } else {
        // Show waiting UI
        console.log('Waiting for random match...');
        // You might want to set state to show waiting status
      }
    } catch (error) {
      console.error('Random match failed:', error.response?.data || error.message);
    } finally {
      setLoading(false);
    }
  };

  // Show loading state while checking auth
  if (userLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
        <h1 className="text-3xl font-bold text-center mb-6">Random Video Chat</h1>
        <Button
          onClick={handleRandomMatch}
          disabled={loading}
          className="w-full py-3 mb-4"
        >
          {loading ? 'Finding random match...' : 'Start Random Chat'}
        </Button>
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-3">Select your interests</h2>
          <div className="flex flex-wrap gap-2">
            {interests.map(interest => (
              <Button
                key={interest.id}
                variant={selectedInterests.includes(interest.id) ? 'primary' : 'outline'}
                onClick={() => {
                  setSelectedInterests(prev =>
                    prev.includes(interest.id)
                      ? prev.filter(id => id !== interest.id)
                      : [...prev, interest.id]
                  );
                }}
                className="text-sm"
              >
                {interest.name}
              </Button>
            ))}
          </div>
        </div>

        {/* <Button
          onClick={handleFindMatch}
          disabled={loading || !user}
          className="w-full py-3"
        >
          {loading ? 'Finding match...' : 'Start Chatting'}
        </Button> */}
      </div>
    </div>
  );
};

export default HomePage;